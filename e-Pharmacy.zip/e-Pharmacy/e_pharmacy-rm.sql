-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2022 at 06:03 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `messagein`
--

CREATE TABLE `messagein` (
  `Id` int(11) NOT NULL,
  `SendTime` datetime DEFAULT NULL,
  `ReceiveTime` datetime DEFAULT NULL,
  `MessageFrom` varchar(80) DEFAULT NULL,
  `MessageTo` varchar(80) DEFAULT NULL,
  `SMSC` varchar(80) DEFAULT NULL,
  `MessageText` text DEFAULT NULL,
  `MessageType` varchar(80) DEFAULT NULL,
  `MessageParts` int(11) DEFAULT NULL,
  `MessagePDU` text DEFAULT NULL,
  `Gateway` varchar(80) DEFAULT NULL,
  `UserId` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messagein`
--

INSERT INTO `messagein` (`Id`, `SendTime`, `ReceiveTime`, `MessageFrom`, `MessageTo`, `SMSC`, `MessageText`, `MessageType`, `MessageParts`, `MessagePDU`, `Gateway`, `UserId`) VALUES
(1, '2022-11-02 05:19:29', NULL, '211', '+254305235027', NULL, '0B05040B8423F00003FB0302,870906890101C651018715060350524F585932000187070603534D415254204D4D530001C65201872F060350524F5859325F3100018720060331302E3130322E36312E343600018721068501872206034E4150475052535F320001C6530187230603383038300001010101C600015501873606037734000187070603534D4152', NULL, NULL, NULL, NULL, NULL),
(2, '2022-11-02 05:19:34', NULL, '211fj', '+254305235027', NULL, '0B05040B8423F00003FB0303,54204D4D5300018739060350524F585932000187340603687474703A2F2F31302E3130322E36312E3233383A383030322F00010101', NULL, NULL, NULL, NULL, NULL),
(3, '2022-11-02 05:19:14', NULL, 'ldskjdf', '+254305235027', NULL, '0B05040B8423F00003FA0201,6C062F1F2DB69180923646443032463643313042394231363544354242413143304143413232424334343239453236423600030B6A00C54503312E310001C6560187070603534D41525420494E5445524E4554000101C65501871106034E4150475052535F330001871006AB0187070603534D41525420494E5445524E455400', NULL, NULL, NULL, NULL, NULL),
(4, '2022-11-02 05:19:19', NULL, 'akjdsl', '+254305235027', NULL, '0B05040B8423F00003FA0202,0187140187080603696E7465726E65740001870906890101C600015501873606037732000187070603534D41525420494E5445524E45540001872206034E4150475052535F330001C65901873A0603687474703A2F2F6D2E736D6172742E636F6D2E7068000187070603484F4D450001871C01010101', NULL, NULL, NULL, NULL, NULL),
(5, '2022-11-02 05:19:24', NULL, 'cnvznljfv', '+254305235027', NULL, '0B05040B8423F00003FB0301,6D062F1F2DB69180923432373832413042464145313131463335303137323744303141433530304134373930423843334500030B6A00C54503312E310001C6560187070603534D415254204D4D53000101C65501871106034E4150475052535F320001871006AB0187070603534D415254204D4D530001870806036D6D730001', NULL, NULL, NULL, NULL, NULL),
(6, '2022-11-02 05:19:29', NULL, 'dsfljiro', '+254305235027', NULL, '0B05040B8423F00003FB0302,870906890101C651018715060350524F585932000187070603534D415254204D4D530001C65201872F060350524F5859325F3100018720060331302E3130322E36312E343600018721068501872206034E4150475052535F320001C6530187230603383038300001010101C600015501873606037734000187070603534D4152', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messagelog`
--

CREATE TABLE `messagelog` (
  `Id` int(11) NOT NULL,
  `SendTime` datetime DEFAULT NULL,
  `ReceiveTime` datetime DEFAULT NULL,
  `StatusCode` int(11) DEFAULT NULL,
  `StatusText` varchar(80) DEFAULT NULL,
  `MessageTo` varchar(80) DEFAULT NULL,
  `MessageFrom` varchar(80) DEFAULT NULL,
  `MessageText` text DEFAULT NULL,
  `MessageType` varchar(80) DEFAULT NULL,
  `MessageId` varchar(80) DEFAULT NULL,
  `ErrorCode` varchar(80) DEFAULT NULL,
  `ErrorText` varchar(80) DEFAULT NULL,
  `Gateway` varchar(80) DEFAULT NULL,
  `MessageParts` int(11) DEFAULT NULL,
  `MessagePDU` text DEFAULT NULL,
  `Connector` varchar(80) DEFAULT NULL,
  `UserId` varchar(80) DEFAULT NULL,
  `UserInfo` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messagelog`
--

INSERT INTO `messagelog` (`Id`, `SendTime`, `ReceiveTime`, `StatusCode`, `StatusText`, `MessageTo`, `MessageFrom`, `MessageText`, `MessageType`, `MessageId`, `ErrorCode`, `ErrorText`, `Gateway`, `MessageParts`, `MessagePDU`, `Connector`, `UserId`, `UserInfo`) VALUES
(9, '2018-02-09 18:00:12', NULL, 200, NULL, '+639486457414', 'yes', NULL, NULL, '1:+639486457414:35', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, '2018-02-09 18:01:12', NULL, 200, NULL, '+639486457414', 'Test to send', NULL, NULL, '1:+639486457414:36', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, '2018-02-09 18:02:58', NULL, 200, NULL, '+639486457414', 'FROM JANNO : Confirmed', NULL, NULL, '1:+639486457414:37', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, '2018-02-09 18:05:22', NULL, 200, NULL, '+639486457414', 'FROM Bachelor of Science and Entrepreneurs : Your order has been .Confirmed', NULL, NULL, '1:+639486457414:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, '2018-02-09 18:08:14', NULL, 200, NULL, '+639486457414', 'FROM Bachelor of Science and Entrepreneurs : Your order has been .Confirmed', NULL, NULL, '1:+639486457414:39', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, '2018-02-09 18:21:41', NULL, 200, NULL, '+639486457414', 'FROM Bachelor of Science and Entrepreneurs : Your order has been .Confirmed', NULL, NULL, '1:+639486457414:40', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, '2018-04-01 22:17:34', NULL, 300, NULL, '09123586545', 'Your code is .6048', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, '2018-04-01 22:18:20', NULL, 300, NULL, '09123586545', 'Your code is .9305', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, '2018-04-01 22:20:15', NULL, 300, NULL, '09123586545', 'Your code is .2924', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, '2018-04-01 22:42:36', NULL, 300, NULL, '09123586545', 'Your code is .6938', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, '2018-04-02 00:40:53', NULL, 300, NULL, '9956112920', 'Your code is .7290', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, '2018-04-02 00:42:14', NULL, 300, NULL, '9956112920', 'Your code is .4506', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, '2018-04-02 00:43:46', NULL, 300, NULL, '9956112920', 'Your code is .4506', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, '2018-04-02 00:45:56', NULL, 300, NULL, '09956112920', 'Your code is .6988', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, '2018-04-02 00:47:17', NULL, 300, NULL, '09956112920', 'Your code is .4380', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, '2018-04-02 00:48:53', NULL, 200, NULL, '639956112920', 'Your code is .5936', NULL, NULL, '1:639956112920:129', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, '2018-04-02 00:50:29', NULL, 200, NULL, '639956112920', 'Your code is .5349', NULL, NULL, '1:639956112920:130', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, '2018-04-02 00:53:32', NULL, 200, NULL, '639956112920', 'Your code is', NULL, NULL, '1:639956112920:131', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, '2018-04-02 00:54:43', NULL, 200, NULL, '639956112920', 'Your code is 3407', NULL, NULL, '1:639956112920:132', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messageout`
--

CREATE TABLE `messageout` (
  `Id` int(11) NOT NULL,
  `MessageTo` varchar(80) DEFAULT NULL,
  `MessageFrom` varchar(80) DEFAULT NULL,
  `MessageText` text DEFAULT NULL,
  `MessageType` varchar(80) DEFAULT NULL,
  `Gateway` varchar(80) DEFAULT NULL,
  `UserId` varchar(80) DEFAULT NULL,
  `UserInfo` text DEFAULT NULL,
  `Priority` int(11) DEFAULT NULL,
  `Scheduled` datetime DEFAULT NULL,
  `ValidityPeriod` int(11) DEFAULT NULL,
  `IsSent` tinyint(1) NOT NULL DEFAULT 0,
  `IsRead` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumber`
--

CREATE TABLE `tblautonumber` (
  `ID` int(11) NOT NULL,
  `AUTOSTART` varchar(11) NOT NULL,
  `AUTOINC` int(11) NOT NULL,
  `AUTOEND` int(11) NOT NULL,
  `AUTOKEY` varchar(12) NOT NULL,
  `AUTONUM` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblautonumber`
--

INSERT INTO `tblautonumber` (`ID`, `AUTOSTART`, `AUTOINC`, `AUTOEND`, `AUTOKEY`, `AUTONUM`) VALUES
(1, '2017', 1, 47, 'PROID', 10),
(2, '0', 1, 97, 'ordernumber', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `CATEGID` int(11) NOT NULL,
  `CATEGORIES` varchar(255) NOT NULL,
  `USERID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`CATEGID`, `CATEGORIES`, `USERID`) VALUES
(5, 'Pills', 0),
(11, 'Coughing Syrup', 0),
(12, 'Anesthetics', 0),
(13, 'Anti-addiction agents', 0),
(14, 'Antibacterials', 0),
(15, 'Anticonvulsants', 0),
(16, 'Anxiolytics', 0),
(17, 'Bipolar agents', 0),
(18, 'Hormone suppressant (pituitary)', 0),
(19, 'Blood glucose regulators', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

CREATE TABLE `tblcustomer` (
  `CUSTOMERID` int(11) NOT NULL,
  `FNAME` varchar(30) NOT NULL,
  `LNAME` varchar(30) NOT NULL,
  `MNAME` varchar(30) NOT NULL,
  `CUSHOMENUM` varchar(90) NOT NULL,
  `STREETADD` text NOT NULL,
  `BRGYADD` text NOT NULL,
  `CITYADD` text NOT NULL,
  `PROVINCE` varchar(80) NOT NULL,
  `COUNTRY` varchar(30) NOT NULL,
  `DBIRTH` date NOT NULL,
  `GENDER` varchar(10) NOT NULL,
  `PHONE` varchar(20) NOT NULL,
  `EMAILADD` varchar(40) NOT NULL,
  `ZIPCODE` int(6) NOT NULL,
  `CUSUNAME` varchar(20) NOT NULL,
  `CUSPASS` varchar(90) NOT NULL,
  `CUSPHOTO` varchar(255) NOT NULL,
  `TERMS` tinyint(4) NOT NULL,
  `DATEJOIN` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcustomer`
--

-- INSERT INTO `tblcustomer` (`CUSTOMERID`, `FNAME`, `LNAME`, `MNAME`, `CUSHOMENUM`, `STREETADD`, `BRGYADD`, `CITYADD`, `PROVINCE`, `COUNTRY`, `DBIRTH`, `GENDER`, `PHONE`, `EMAILADD`, `ZIPCODE`, `CUSUNAME`, `CUSPASS`, `CUSPHOTO`, `TERMS`, `DATEJOIN`) VALUES
-- (1, 'janobe', 'Palacios', '', '321', 'Coloso Street', 'brgy. 1', 'Kabankalan City', 'Negros Occidental', 'Philippines', '0000-00-00', 'Male', '+639956112920', '', 6111, 'kenjie@yahoo.com', '1dd4efc811372cd1efe855981a8863d10ddde1ca', 'customer_image/a1157016c5d8272126380b27a59e2e7e.jpg', 1, '2015-11-26'),
-- (2, 'Mark Anthony', 'Geasin', '', '1234', 'paglaom', 'dancalan', 'ilog', 'negros occ', 'philippines', '0000-00-00', '', '091023333234', '', 6111, 'bboy', '0377588176145a8f0d837ff6e9bf0c1616268387', 'customer_image/10801930_959054964122877_391305007291646162_n.jpg', 1, '2015-11-26'),
-- (3, 'Jano', 'Palacios', '', '12312', 's', 'brgy 1', 'kabankalan city', 'negross occidental', 'philippines', '0000-00-00', 'Male', '21312312312', '', 6111, 'jan', '53199fa57fdf5676d03d89fbdd26e69a927766fc', 'customer_image/Tropical-Beach-Wallpaper.jpg', 1, '2017-12-08'),
-- (4, 'Jamei', 'Laveste', '', '', '', '', 'kabankalan city', '', '', '0000-00-00', 'Female', '362656556', '', 0, 'jame', 'f144dcce05af4d40fa0aeba34b05f4472472a4de', 'customer_image/1351064148bpguarhW.jpg', 1, '2018-01-23'),
-- (5, 'Jeanniebe', 'Palacios', '', '', '', '', 'Kab City', '', '', '0000-00-00', 'Female', '+639486457414', '', 0, 'bebe', 'd079a1c06803587ea09bff3f44a567e19169e7b5', '', 1, '2018-02-09'),
-- (6, 'Janry', 'Tan', '', '', '', '', 'Kab City', '', '', '0000-00-00', 'Male', '0234234', '', 0, 'jan', '0271c5467994a9e88e01be5b7e1f5f43d0ab93d2', '', 1, '2018-04-01'),
-- (7, 'Jake', 'Cuenca', '', '', '', '', 'Kabankalan City', '', '', '0000-00-00', 'Male', '639305235027', '', 0, 'jake', '403ba16f713c8371eef121530a922824be29b68a', '', 1, '2018-04-16'),
-- (8, 'Jake', 'Tam', '', '', '', '', 'Kab City', '', '', '0000-00-00', 'Male', '021312312', '', 0, 'j', '30e1fe53111f7e583c382596a32885fd27283970', '', 1, '2018-09-23'),
-- (9, 'Annie', 'Paredes', '', '', '', '', 's', '', '', '0000-00-00', 'Female', '12312312', '', 0, 'an', 'aa46142b604e671794a84129896d4dec508dec81', 'customer_image/shirt2.jpg', 1, '2019-08-20'),
-- (10, 'suu', 'suu', '', '', '', '', 'Nairobi', '', '', '0000-00-00', 'Female', '07019292928', '', 0, 'suu  ', '1ed0fcb524238ab9260c2f6b1ea718bbb1ad6c02', '', 1, '2022-05-25');

INSERT INTO `tblcustomer` (`CUSTOMERID`, `FNAME`, `LNAME`, `MNAME`, `CUSHOMENUM`, `STREETADD`, `BRGYADD`, `CITYADD`, `PROVINCE`, `COUNTRY`, `DBIRTH`, `GENDER`, `PHONE`, `EMAILADD`, `ZIPCODE`, `CUSUNAME`, `CUSPASS`, `CUSPHOTO`, `TERMS`, `DATEJOIN`) VALUES
(10, 'suu', 'suu', '', '', '', '', 'Nairobi', '', '', '0000-00-00', 'Female', '07019292928', '', 0, 'suu  ', '1ed0fcb524238ab9260c2f6b1ea718bbb1ad6c02', '', 1, '2022-05-25'),
(11, 'osman', 'suu', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '63274831674', '', 0, 'suu osman123456', 'd0cd5d15e44c11538db7201097d92085b800157b', '', 1, '2022-05-31'),
(12, 'ahmed', 'hassan', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '25479098987675', '', 0, 'ahmedhassan111', '9fe010699ef5fd611982eee717fd2e85b7299b62', '', 1, '2022-06-06'),
(13, 'seif', 'yussuf', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '0701699145', '', 0, 'YS', '00f05318ada2ca4eec767c81aa98d517d56ed46f', '', 1, '2022-06-06'),
(14, 'Ceelabe', 'Farah', '', '', '', '', 'Nairobi', '', '', '0000-00-00', 'Male', '709786170', '', 0, 'CeelabeY', '47ad7d6cbad5534cbcb4c26cb36eba30277a9cbe', '', 1, '2022-06-07'),
(15, 'suu', 'osman', '', '', '', '', '321', '', '', '0000-00-00', 'Female', '0748534752', '', 0, 'suu23456', '9454b1baa9d784f24d9c1b9aef65c3d2fbf417a9', '', 1, '2022-06-09'),
(16, 'syosman', 'unite', '', '', '', '', 'naitf', '', '', '0000-00-00', 'Female', '0954443', '', 0, 'osman33', '77b85d21a29fcf63fb9480efe21fcf1883917c0f', '', 1, '2022-06-09'),
(17, 'suu', 'osman', '', '', '', '', '473', '', '', '0000-00-00', 'Female', '9478302', '', 0, 'suu123', '0e86882e03251ed6297cbf395bc7b8e2d6120566', '', 1, '2022-06-09'),
(18, 'suuosman', 'yasin', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '483925', '', 0, 'osmann123', '0ba4ee5d3c6d6bf3d4e42dea3a7b8909548b0528', '', 1, '2022-06-09'),
(19, 'raudha', 'bashir', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '342483874', '', 0, 'raudha', '59868c6d44d0a34a5ca9b692c14a5848368badad', '', 1, '2022-06-09'),
(20, 'kevin', 'jana', '', '', '', '', 'hungary', '', '', '0000-00-00', 'Male', '073827481', '', 0, 'kevin', 'db3c4b003204f4b052413de296d1446636d02452', '', 1, '2022-06-09'),
(21, 'musa', 'ali', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '7534890275', '', 0, 'musaali', '3900d75c11e4a917840d173deb278cd040dd930c', '', 1, '2022-06-09'),
(22, 'farhiya', 'hani', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '83264789', '', 0, 'farhiya', '407e5aca8a02b20a6c248a43810039812cbf10bd', '', 1, '2022-06-09'),
(23, 'yasim', 'adam', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '74382222222224', '', 0, 'yasin123', '598d4b12b674f29adead9aa1dadf4193a3ddec7b', '', 1, '2022-06-09'),
(24, 'naima', 'hajji', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Female', '07483254', '', 0, 'naima', '032cbb1d4271f0dd78522edf90cef3b83e0fd7c1', '', 1, '2022-06-09'),
(25, 'kamua', 'david', '', '', '', '', 'kitengela', '', '', '0000-00-00', 'Male', '0858639706', '', 0, 'david', '5ad7ac9412efd3cb9bc0fa558b7b880443ec30bd', '', 1, '2022-06-09'),
(26, 'janice', 'mali', '', '', '', '', 'india', '', '', '0000-00-00', 'Female', '078437022', '', 0, 'janice', 'ad5f1791e2344d0f98ed0d19600d48031986bd08', '', 1, '2022-06-09'),
(27, 'chandler', 'bing', '', '', '', '', 'new york', '', '', '0000-00-00', 'Male', '073265483', '', 0, 'chandler', '9afe8342bca96a3a62ed38e8d0bee462554f7ee0', '', 1, '2022-06-09'),
(28, 'monica', 'geller', '', '', '', '', 'jersey', '', '', '0000-00-00', 'Female', '0735124351', '', 0, 'monica', '93b4e4c8a4c8c0a1149ae96a19dcf08f0a1a5f12', '', 1, '2022-06-09'),
(29, 'farida', 'bee', '', '', '', '', 'kiambu', '', '', '0000-00-00', 'Female', '073264243', '', 0, 'farida', 'dcea434511884235e625749049f7cfeae4be1bf1', '', 1, '2022-06-09'),
(30, 'oman', 'osama', '', '', '', '', 'new york', '', '', '0000-00-00', 'Female', '0742654554', '', 0, 'oman', 'ca889c84f5d5ffd8b7b40ac7acd6a9d6a388f0ec', '', 1, '2022-06-09'),
(31, 'gabriel', 'gabriel', '', '', '', '', 'vienna', '', '', '0000-00-00', 'Female', '0736728564', '', 0, 'gabriel', '8a8079e5209c1a0b7b8998f5b72d0c7e86eefe89', 'customer_image/w__CYGIU_400x400.jpg', 1, '2022-06-09'),
(32, 'jamila', 'osman', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '254784379524', '', 0, 'jamila', 'a77df00218fa9ac12ac14060d774d25b16a3dce7', '', 1, '2022-06-16'),
(33, 'frisby', 'kala', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '2546587386', '', 0, 'frisby', '3bd9cd69cb740b42c6508cf19ac6cad1d3b136a1', '', 1, '2022-06-16'),
(34, 'kamaal', 'jill', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '57341389570', '', 0, 'kamaal', '55e34133ccc3387a56f59705ba0cbb8095339741', '', 1, '2022-06-16'),
(35, 'ahmed', 'hassna', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '084832652', '', 0, 'ahmed', '3c501a4f7dc43ee8ff681bbe7202dbf50cd6cfa7', '', 1, '2022-06-16'),
(36, 'jamil', 'ali', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '0788997766', '', 0, 'jamil123', '2f14d3108e5b36a4b98cbb76804d9ab0b86d7926', '', 1, '2022-06-16'),
(37, 'ali', 'kevin', '', '', '', '', 'naiorbi', '', '', '0000-00-00', 'Male', '0865527432', '', 0, 'ali5566', '5368fe2cbfd4c9f996a2750a46b0cafd54566e62', '', 1, '2022-06-16'),
(38, 'gabriel', 'buru', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '96578743867', '', 0, 'gabriel', '5e50ad8f11221b2b0d82683b31c3d1f11f43389d', '', 1, '2022-06-16'),
(39, 'yasinnn', 'unagi', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '8756802439', '', 0, 'yasinn6677', 'f33386d70b01b8ccf2ce5cf6c9d00fbbdbe0a6c0', '', 1, '2022-06-16'),
(40, 'nunu', 'jaj', '', '', '', '', 'hongkong', '', '', '0000-00-00', 'Male', '42833332489', '', 0, 'nunu', '330345c067fa4cd5c51eed8959c854e8d7b1f34d', '', 1, '2022-06-16'),
(41, 'harris', 'unima', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '8767656789', '', 0, 'harris44', 'fc470d5760d7ba437ccc31b879b527b1c3f38654', '', 1, '2022-06-16'),
(42, 'ilmi', 'adam', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '4837280332', '', 0, 'ilmi', '8a48f359b86353beaf7f852740ee43c45750ffe1', '', 1, '2022-06-16'),
(43, 'naima', 'adam', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Female', '48360252349', '', 0, 'naima1234', '84d1e0e7514d2da0798a0010778a47e9cc94d677', '', 1, '2022-06-16'),
(44, 'halima', 'adam', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '85480923', '', 0, 'halima', '6c31cf63cb05207b3a95bc32f01527f6df71e2ef', '', 1, '2022-06-16'),
(45, 'batuulo', 'nani', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '5874382901', '', 0, 'batuulo', 'fe64d6cc1e805ade802580f93f4c64d491c45f83', '', 1, '2022-06-16'),
(46, 'zak', 'olama', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '73487529304', '', 0, 'zakyy', '31a6d44c138c3e1752c582169faf23b4d165304e', '', 1, '2022-06-16'),
(47, 'hannad', 'osman', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '473750348782', '', 0, 'hannad', 'f00e93c0971c23a3086875a2517a790275156cfd', '', 1, '2022-06-16'),
(48, 'anzal', 'yasin', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '8542378362', '', 0, 'anzal', 'af8fecd0cc5cadf7c5418e116761cd663fe40388', '', 1, '2022-06-16'),
(49, 'abdullahi', 'osman', '', '', '', '', 'london', '', '', '0000-00-00', 'Male', '436782932', '', 0, 'abdulalhi', '17b7e94c53936fcca27498a5fd469608ec673a4b', '', 1, '2022-06-16'),
(50, 'abbas', 'yasin', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '2485629384', '', 0, 'abbas45673', '3c4576e69ed183d27b64e756bbf4efd29b4dacd5', '', 1, '2022-06-16'),
(51, 'annie', 'kaniu', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '584378397', '', 0, 'ayaan', 'd75da63185da5e320014e332343c1e0a7fafadf9', 'customer_image/kaak.PNG', 1, '2022-06-16'),
(52, 'Kendric', 'arthur', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '25476389897', '', 0, 'Kendric', '191edbf3953c0c963179936b88374e87900a04b6', 'customer_image/ken.jpg', 1, '2022-06-22'),
(53, 'seif', 'seif', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '0701699145', '', 0, 'seif', '3991787c256ac7246f76754872283bf1384429b8', '', 1, '2022-06-29');

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

CREATE TABLE `tblorder` (
  `ORDERID` int(11) NOT NULL,
  `PROID` int(11) NOT NULL,
  `ORDEREDQTY` int(11) NOT NULL,
  `ORDEREDPRICE` double NOT NULL,
  `ORDEREDNUM` int(11) NOT NULL,
  `USERID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`ORDERID`, `PROID`, `ORDEREDQTY`, `ORDEREDPRICE`, `ORDEREDNUM`, `USERID`) VALUES
(3, 201738, 1, 199, 94, 0),
(4, 201744, 1, 1500, 96, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `PROID` int(11) NOT NULL,
  `PRODESC` varchar(255) DEFAULT NULL,
  `INGREDIENTS` varchar(255) NOT NULL,
  `PROQTY` int(11) DEFAULT NULL,
  `ORIGINALPRICE` double NOT NULL,
  `PROPRICE` double DEFAULT NULL,
  `CATEGID` int(11) DEFAULT NULL,
  `IMAGES` varchar(255) DEFAULT NULL,
  `PROSTATS` varchar(30) DEFAULT NULL,
  `OWNERNAME` varchar(90) NOT NULL,
  `OWNERPHONE` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`PROID`, `PRODESC`, `INGREDIENTS`, `PROQTY`, `ORIGINALPRICE`, `PROPRICE`, `CATEGID`, `IMAGES`, `PROSTATS`, `OWNERNAME`, `OWNERPHONE`) VALUES
(201743, 'a medicated, syruplike fluid, usually flavored and nonnarcotic or mildly narcotic, for relieving coughs or soothing irritated throats', '', 20, 800, 1200, 11, 'uploaded_photos/cough.jpg', 'Available', 'suu', '0701676766'),
(201744, ' It works by stopping the production of certain natural substances that cause fever, pain, swelling, and blood clots. Aspirin is also available in combination with other medications such as antacids, pain relievers, and cough and cold medications.', '', 49, 500, 1500, 5, 'uploaded_photos/asprin.jpg', 'Available', 'suu', '070139829'),
(201745, 'medicines that reduce or relieve headaches, sore muscles, arthritis, or other aches and pains.', '', 50, 560, 1560, 5, 'uploaded_photos/painkiller.jpg', 'Available', 'suu', '0701998718'),
(201746, 'fight bacterial infections in people and animals. They work by killing the bacteria or by making it hard for the bacteria to grow and multiply', '', 500, 607, 1200, 5, 'uploaded_photos/antibiotic.jpg', 'Available', 'suu', '07012939829');

-- --------------------------------------------------------

--
-- Table structure for table `tblpromopro`
--

CREATE TABLE `tblpromopro` (
  `PROMOID` int(11) NOT NULL,
  `PROID` int(11) NOT NULL,
  `PRODISCOUNT` double NOT NULL,
  `PRODISPRICE` double NOT NULL,
  `PROBANNER` tinyint(4) NOT NULL,
  `PRONEW` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpromopro`
--

INSERT INTO `tblpromopro` (`PROMOID`, `PROID`, `PRODISCOUNT`, `PRODISPRICE`, `PROBANNER`, `PRONEW`) VALUES
(1, 201737, 0, 119, 0, 0),
(2, 201738, 0, 199, 0, 0),
(7, 201743, 0, 1200, 0, 0),
(8, 201744, 0, 1500, 0, 0),
(9, 201745, 0, 1560, 0, 0),
(10, 201746, 0, 1200, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblsetting`
--

CREATE TABLE `tblsetting` (
  `SETTINGID` int(11) NOT NULL,
  `PLACE` text NOT NULL,
  `BRGY` varchar(90) NOT NULL,
  `DELPRICE` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsetting`
--

INSERT INTO `tblsetting` (`SETTINGID`, `PLACE`, `BRGY`, `DELPRICE`) VALUES
(1, 'Nairobi', 'NAI. 1', 50),
(2, 'Mombasa ', 'MBSA 1', 70);

-- --------------------------------------------------------

--
-- Table structure for table `tblstockin`
--

CREATE TABLE `tblstockin` (
  `STOCKINID` int(11) NOT NULL,
  `STOCKDATE` datetime DEFAULT NULL,
  `PROID` int(11) DEFAULT NULL,
  `STOCKQTY` int(11) DEFAULT NULL,
  `STOCKPRICE` double DEFAULT NULL,
  `USERID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblsummary`
--

CREATE TABLE `tblsummary` (
  `SUMMARYID` int(11) NOT NULL,
  `ORDEREDDATE` datetime NOT NULL,
  `CUSTOMERID` int(11) NOT NULL,
  `ORDEREDNUM` int(11) NOT NULL,
  `DELFEE` double NOT NULL,
  `PAYMENT` double NOT NULL,
  `PAYMENTMETHOD` varchar(30) NOT NULL,
  `ORDEREDSTATS` varchar(30) NOT NULL,
  `ORDEREDREMARKS` varchar(125) NOT NULL,
  `CLAIMEDADTE` datetime NOT NULL,
  `HVIEW` tinyint(4) NOT NULL,
  `USERID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsummary`
--

INSERT INTO `tblsummary` (`SUMMARYID`, `ORDEREDDATE`, `CUSTOMERID`, `ORDEREDNUM`, `DELFEE`, `PAYMENT`, `PAYMENTMETHOD`, `ORDEREDSTATS`, `ORDEREDREMARKS`, `CLAIMEDADTE`, `HVIEW`, `USERID`) VALUES
(1, '2022-08-21 06:24:24', 9, 93, 0, 0, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-05-25 00:00:00', 0, 0),
(3, '2022-08-21 06:27:09', 9, 94, 70, 269, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2019-08-21 00:00:00', 1, 0),
(4, '2022-05-25 05:41:20', 10, 96, 70, 1500, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-05-25 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbluseraccount`
--

CREATE TABLE `tbluseraccount` (
  `USERID` int(11) NOT NULL,
  `U_NAME` varchar(122) NOT NULL,
  `U_USERNAME` varchar(122) NOT NULL,
  `U_PASS` varchar(122) NOT NULL,
  `U_ROLE` varchar(30) NOT NULL,
  `USERIMAGE` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluseraccount`
--

INSERT INTO `tbluseraccount` (`USERID`, `U_NAME`, `U_USERNAME`, `U_PASS`, `U_ROLE`, `USERIMAGE`) VALUES
(124, 'suu', 'suheiba', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', 'photos/COC-war-base-design.jpg'),
(126, 'Suheiba Yasin', 'suu', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', 'photos/1570180.jpg'),
(127, 'Anime', 'anime', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblwishlist`
--

CREATE TABLE `tblwishlist` (
  `id` int(11) NOT NULL,
  `CUSID` int(11) NOT NULL,
  `PROID` int(11) NOT NULL,
  `WISHDATE` date NOT NULL,
  `WISHSTATS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblwishlist`
--

INSERT INTO `tblwishlist` (`id`, `CUSID`, `PROID`, `WISHDATE`, `WISHSTATS`) VALUES
(2, 9, 201742, '2019-08-21', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messagein`
--
ALTER TABLE `messagein`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `messagelog`
--
ALTER TABLE `messagelog`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IDX_MessageId` (`MessageId`,`SendTime`);

--
-- Indexes for table `messageout`
--
ALTER TABLE `messageout`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IDX_IsRead` (`IsRead`);

--
-- Indexes for table `tblautonumber`
--
ALTER TABLE `tblautonumber`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`CATEGID`);

--
-- Indexes for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  ADD PRIMARY KEY (`CUSTOMERID`);

--
-- Indexes for table `tblorder`
--
ALTER TABLE `tblorder`
  ADD PRIMARY KEY (`ORDERID`),
  ADD KEY `USERID` (`USERID`),
  ADD KEY `PROID` (`PROID`),
  ADD KEY `ORDEREDNUM` (`ORDEREDNUM`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`PROID`),
  ADD KEY `CATEGID` (`CATEGID`);

--
-- Indexes for table `tblpromopro`
--
ALTER TABLE `tblpromopro`
  ADD PRIMARY KEY (`PROMOID`),
  ADD UNIQUE KEY `PROID` (`PROID`);

--
-- Indexes for table `tblsetting`
--
ALTER TABLE `tblsetting`
  ADD PRIMARY KEY (`SETTINGID`);

--
-- Indexes for table `tblstockin`
--
ALTER TABLE `tblstockin`
  ADD PRIMARY KEY (`STOCKINID`),
  ADD KEY `PROID` (`PROID`,`USERID`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tblsummary`
--
ALTER TABLE `tblsummary`
  ADD PRIMARY KEY (`SUMMARYID`),
  ADD UNIQUE KEY `ORDEREDNUM` (`ORDEREDNUM`),
  ADD KEY `CUSTOMERID` (`CUSTOMERID`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tbluseraccount`
--
ALTER TABLE `tbluseraccount`
  ADD PRIMARY KEY (`USERID`);

--
-- Indexes for table `tblwishlist`
--
ALTER TABLE `tblwishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messagein`
--
ALTER TABLE `messagein`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `messagelog`
--
ALTER TABLE `messagelog`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `messageout`
--
ALTER TABLE `messageout`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblautonumber`
--
ALTER TABLE `tblautonumber`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `CATEGID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  MODIFY `CUSTOMERID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblorder`
--
ALTER TABLE `tblorder`
  MODIFY `ORDERID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblpromopro`
--
ALTER TABLE `tblpromopro`
  MODIFY `PROMOID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblsetting`
--
ALTER TABLE `tblsetting`
  MODIFY `SETTINGID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblstockin`
--
ALTER TABLE `tblstockin`
  MODIFY `STOCKINID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblsummary`
--
ALTER TABLE `tblsummary`
  MODIFY `SUMMARYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbluseraccount`
--
ALTER TABLE `tbluseraccount`
  MODIFY `USERID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `tblwishlist`
--
ALTER TABLE `tblwishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
