-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2022 at 01:24 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `CATEGID` int(11) NOT NULL,
  `CATEGORIES` varchar(255) NOT NULL,
  `USERID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`CATEGID`, `CATEGORIES`, `USERID`) VALUES
(5, 'Pills', 0),
(11, 'Coughing Syrup', 0),
(12, 'Anesthetics', 0),
(13, 'Anti-addiction agents', 0),
(14, 'Antibacterials', 0),
(15, 'Anticonvulsants', 0),
(16, 'Anxiolytics', 0),
(17, 'Bipolar agents', 0),
(18, 'Hormone suppressant (pituitary)', 0),
(19, 'Blood glucose regulators', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

CREATE TABLE `tblcustomer` (
  `CUSTOMERID` int(11) NOT NULL,
  `FNAME` varchar(30) NOT NULL,
  `LNAME` varchar(30) NOT NULL,
  `MNAME` varchar(30) NOT NULL,
  `CUSHOMENUM` varchar(90) NOT NULL,
  `STREETADD` text NOT NULL,
  `BRGYADD` text NOT NULL,
  `CITYADD` text NOT NULL,
  `PROVINCE` varchar(80) NOT NULL,
  `COUNTRY` varchar(30) NOT NULL,
  `DBIRTH` date NOT NULL,
  `GENDER` varchar(10) NOT NULL,
  `PHONE` varchar(20) NOT NULL,
  `EMAILADD` varchar(40) NOT NULL,
  `ZIPCODE` int(6) NOT NULL,
  `CUSUNAME` varchar(20) NOT NULL,
  `CUSPASS` varchar(90) NOT NULL,
  `CUSPHOTO` varchar(255) NOT NULL,
  `TERMS` tinyint(4) NOT NULL,
  `DATEJOIN` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcustomer`
--

INSERT INTO `tblcustomer` (`CUSTOMERID`, `FNAME`, `LNAME`, `MNAME`, `CUSHOMENUM`, `STREETADD`, `BRGYADD`, `CITYADD`, `PROVINCE`, `COUNTRY`, `DBIRTH`, `GENDER`, `PHONE`, `EMAILADD`, `ZIPCODE`, `CUSUNAME`, `CUSPASS`, `CUSPHOTO`, `TERMS`, `DATEJOIN`) VALUES
(10, 'suu', 'suu', '', '', '', '', 'Nairobi', '', '', '0000-00-00', 'Female', '07019292928', '', 0, 'suu  ', '1ed0fcb524238ab9260c2f6b1ea718bbb1ad6c02', '', 1, '2022-05-25'),
(11, 'osman', 'suu', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '63274831674', '', 0, 'suu osman123456', 'd0cd5d15e44c11538db7201097d92085b800157b', '', 1, '2022-05-31'),
(12, 'ahmed', 'hassan', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '25479098987675', '', 0, 'ahmedhassan111', '9fe010699ef5fd611982eee717fd2e85b7299b62', '', 1, '2022-06-06'),
(13, 'seif', 'yussuf', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '0701699145', '', 0, 'YS', '00f05318ada2ca4eec767c81aa98d517d56ed46f', '', 1, '2022-06-06'),
(14, 'Ceelabe', 'Farah', '', '', '', '', 'Nairobi', '', '', '0000-00-00', 'Male', '709786170', '', 0, 'CeelabeY', '47ad7d6cbad5534cbcb4c26cb36eba30277a9cbe', '', 1, '2022-06-07'),
(15, 'suu', 'osman', '', '', '', '', '321', '', '', '0000-00-00', 'Female', '0748534752', '', 0, 'suu23456', '9454b1baa9d784f24d9c1b9aef65c3d2fbf417a9', '', 1, '2022-06-09'),
(16, 'syosman', 'unite', '', '', '', '', 'naitf', '', '', '0000-00-00', 'Female', '0954443', '', 0, 'osman33', '77b85d21a29fcf63fb9480efe21fcf1883917c0f', '', 1, '2022-06-09'),
(17, 'suu', 'osman', '', '', '', '', '473', '', '', '0000-00-00', 'Female', '9478302', '', 0, 'suu123', '0e86882e03251ed6297cbf395bc7b8e2d6120566', '', 1, '2022-06-09'),
(18, 'suuosman', 'yasin', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '483925', '', 0, 'osmann123', '0ba4ee5d3c6d6bf3d4e42dea3a7b8909548b0528', '', 1, '2022-06-09'),
(19, 'raudha', 'bashir', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '342483874', '', 0, 'raudha', '59868c6d44d0a34a5ca9b692c14a5848368badad', '', 1, '2022-06-09'),
(20, 'kevin', 'jana', '', '', '', '', 'hungary', '', '', '0000-00-00', 'Male', '073827481', '', 0, 'kevin', 'db3c4b003204f4b052413de296d1446636d02452', '', 1, '2022-06-09'),
(21, 'musa', 'ali', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '7534890275', '', 0, 'musaali', '3900d75c11e4a917840d173deb278cd040dd930c', '', 1, '2022-06-09'),
(22, 'farhiya', 'hani', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '83264789', '', 0, 'farhiya', '407e5aca8a02b20a6c248a43810039812cbf10bd', '', 1, '2022-06-09'),
(23, 'yasim', 'adam', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '74382222222224', '', 0, 'yasin123', '598d4b12b674f29adead9aa1dadf4193a3ddec7b', '', 1, '2022-06-09'),
(24, 'naima', 'hajji', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Female', '07483254', '', 0, 'naima', '032cbb1d4271f0dd78522edf90cef3b83e0fd7c1', '', 1, '2022-06-09'),
(25, 'kamua', 'david', '', '', '', '', 'kitengela', '', '', '0000-00-00', 'Male', '0858639706', '', 0, 'david', '5ad7ac9412efd3cb9bc0fa558b7b880443ec30bd', '', 1, '2022-06-09'),
(26, 'janice', 'mali', '', '', '', '', 'india', '', '', '0000-00-00', 'Female', '078437022', '', 0, 'janice', 'ad5f1791e2344d0f98ed0d19600d48031986bd08', '', 1, '2022-06-09'),
(27, 'chandler', 'bing', '', '', '', '', 'new york', '', '', '0000-00-00', 'Male', '073265483', '', 0, 'chandler', '9afe8342bca96a3a62ed38e8d0bee462554f7ee0', '', 1, '2022-06-09'),
(28, 'monica', 'geller', '', '', '', '', 'jersey', '', '', '0000-00-00', 'Female', '0735124351', '', 0, 'monica', '93b4e4c8a4c8c0a1149ae96a19dcf08f0a1a5f12', '', 1, '2022-06-09'),
(29, 'farida', 'bee', '', '', '', '', 'kiambu', '', '', '0000-00-00', 'Female', '073264243', '', 0, 'farida', 'dcea434511884235e625749049f7cfeae4be1bf1', '', 1, '2022-06-09'),
(30, 'oman', 'osama', '', '', '', '', 'new york', '', '', '0000-00-00', 'Female', '0742654554', '', 0, 'oman', 'ca889c84f5d5ffd8b7b40ac7acd6a9d6a388f0ec', '', 1, '2022-06-09'),
(31, 'gabriel', 'gabriel', '', '', '', '', 'vienna', '', '', '0000-00-00', 'Female', '0736728564', '', 0, 'gabriel', '8a8079e5209c1a0b7b8998f5b72d0c7e86eefe89', 'customer_image/w__CYGIU_400x400.jpg', 1, '2022-06-09'),
(32, 'jamila', 'osman', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '254784379524', '', 0, 'jamila', 'a77df00218fa9ac12ac14060d774d25b16a3dce7', '', 1, '2022-06-16'),
(33, 'frisby', 'kala', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '2546587386', '', 0, 'frisby', '3bd9cd69cb740b42c6508cf19ac6cad1d3b136a1', '', 1, '2022-06-16'),
(34, 'kamaal', 'jill', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '57341389570', '', 0, 'kamaal', '55e34133ccc3387a56f59705ba0cbb8095339741', '', 1, '2022-06-16'),
(35, 'ahmed', 'hassna', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '084832652', '', 0, 'ahmed', '3c501a4f7dc43ee8ff681bbe7202dbf50cd6cfa7', '', 1, '2022-06-16'),
(36, 'jamil', 'ali', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '0788997766', '', 0, 'jamil123', '2f14d3108e5b36a4b98cbb76804d9ab0b86d7926', '', 1, '2022-06-16'),
(37, 'ali', 'kevin', '', '', '', '', 'naiorbi', '', '', '0000-00-00', 'Male', '0865527432', '', 0, 'ali5566', '5368fe2cbfd4c9f996a2750a46b0cafd54566e62', '', 1, '2022-06-16'),
(38, 'gabriel', 'buru', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '96578743867', '', 0, 'gabriel', '5e50ad8f11221b2b0d82683b31c3d1f11f43389d', '', 1, '2022-06-16'),
(39, 'yasinnn', 'unagi', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '8756802439', '', 0, 'yasinn6677', 'f33386d70b01b8ccf2ce5cf6c9d00fbbdbe0a6c0', '', 1, '2022-06-16'),
(40, 'nunu', 'jaj', '', '', '', '', 'hongkong', '', '', '0000-00-00', 'Male', '42833332489', '', 0, 'nunu', '330345c067fa4cd5c51eed8959c854e8d7b1f34d', '', 1, '2022-06-16'),
(41, 'harris', 'unima', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '8767656789', '', 0, 'harris44', 'fc470d5760d7ba437ccc31b879b527b1c3f38654', '', 1, '2022-06-16'),
(42, 'ilmi', 'adam', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '4837280332', '', 0, 'ilmi', '8a48f359b86353beaf7f852740ee43c45750ffe1', '', 1, '2022-06-16'),
(43, 'naima', 'adam', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Female', '48360252349', '', 0, 'naima1234', '84d1e0e7514d2da0798a0010778a47e9cc94d677', '', 1, '2022-06-16'),
(44, 'halima', 'adam', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '85480923', '', 0, 'halima', '6c31cf63cb05207b3a95bc32f01527f6df71e2ef', '', 1, '2022-06-16'),
(45, 'batuulo', 'nani', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '5874382901', '', 0, 'batuulo', 'fe64d6cc1e805ade802580f93f4c64d491c45f83', '', 1, '2022-06-16'),
(46, 'zak', 'olama', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '73487529304', '', 0, 'zakyy', '31a6d44c138c3e1752c582169faf23b4d165304e', '', 1, '2022-06-16'),
(47, 'hannad', 'osman', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '473750348782', '', 0, 'hannad', 'f00e93c0971c23a3086875a2517a790275156cfd', '', 1, '2022-06-16'),
(48, 'anzal', 'yasin', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '8542378362', '', 0, 'anzal', 'af8fecd0cc5cadf7c5418e116761cd663fe40388', '', 1, '2022-06-16'),
(49, 'abdullahi', 'osman', '', '', '', '', 'london', '', '', '0000-00-00', 'Male', '436782932', '', 0, 'abdulalhi', '17b7e94c53936fcca27498a5fd469608ec673a4b', '', 1, '2022-06-16'),
(50, 'abbas', 'yasin', '', '', '', '', 'mombasa', '', '', '0000-00-00', 'Male', '2485629384', '', 0, 'abbas45673', '3c4576e69ed183d27b64e756bbf4efd29b4dacd5', '', 1, '2022-06-16'),
(51, 'annie', 'kaniu', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Female', '584378397', '', 0, 'ayaan', 'd75da63185da5e320014e332343c1e0a7fafadf9', 'customer_image/kaak.PNG', 1, '2022-06-16'),
(52, 'Kendric', 'arthur', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '25476389897', '', 0, 'Kendric', '191edbf3953c0c963179936b88374e87900a04b6', 'customer_image/ken.jpg', 1, '2022-06-22'),
(53, 'seif', 'seif', '', '', '', '', 'nairobi', '', '', '0000-00-00', 'Male', '0701699145', '', 0, 'seif', '3991787c256ac7246f76754872283bf1384429b8', '', 1, '2022-06-29');

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

CREATE TABLE `tblorder` (
  `ORDERID` int(11) NOT NULL,
  `PROID` int(11) NOT NULL,
  `ORDEREDQTY` int(11) NOT NULL,
  `ORDEREDPRICE` double NOT NULL,
  `ORDEREDNUM` int(11) NOT NULL,
  `USERID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`ORDERID`, `PROID`, `ORDEREDQTY`, `ORDEREDPRICE`, `ORDEREDNUM`, `USERID`) VALUES
(3, 201738, 1, 199, 94, 0),
(4, 201744, 1, 1500, 96, 0),
(5, 201743, 1, 1200, 97, 0),
(6, 201744, 1, 1500, 98, 0),
(7, 201749, 1, 50000, 99, 0),
(8, 201744, 1, 1500, 99, 0),
(9, 201743, 1, 1200, 100, 0),
(10, 201744, 1, 1500, 101, 0),
(11, 201746, 1, 1200, 102, 0),
(12, 201743, 1, 1200, 103, 0),
(13, 201744, 1, 1500, 104, 0),
(14, 201744, 1, 1500, 105, 0),
(15, 201744, 1, 1500, 106, 0),
(16, 201743, 1, 1200, 107, 0),
(17, 201747, 1, 1800, 108, 0),
(18, 201743, 1, 1200, 109, 0),
(19, 201743, 1, 1200, 110, 0),
(20, 201747, 1, 1800, 110, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `PROID` int(11) NOT NULL,
  `PRODESC` varchar(255) DEFAULT NULL,
  `INGREDIENTS` varchar(255) NOT NULL,
  `PROQTY` int(11) DEFAULT NULL,
  `ORIGINALPRICE` double NOT NULL,
  `PROPRICE` double DEFAULT NULL,
  `CATEGID` int(11) DEFAULT NULL,
  `IMAGES` varchar(255) DEFAULT NULL,
  `PROSTATS` varchar(30) DEFAULT NULL,
  `OWNERNAME` varchar(90) NOT NULL,
  `OWNERPHONE` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`PROID`, `PRODESC`, `INGREDIENTS`, `PROQTY`, `ORIGINALPRICE`, `PROPRICE`, `CATEGID`, `IMAGES`, `PROSTATS`, `OWNERNAME`, `OWNERPHONE`) VALUES
(201743, 'a medicated, syruplike fluid, usually flavored and nonnarcotic or mildly narcotic, for relieving coughs or soothing irritated throats', '', 14, 800, 1200, 11, 'uploaded_photos/cough.jpg', 'NotAvailable', 'suu', '0701676766'),
(201744, ' It works by stopping the production of certain natural substances that cause fever, pain, swelling, and blood clots. Aspirin is also available in combination with other medications such as antacids, pain relievers, and cough and cold medications.', '', 43, 500, 1500, 5, 'uploaded_photos/asprin.jpg', 'Available', 'suu', '070139829'),
(201745, 'medicines that reduce or relieve headaches, sore muscles, arthritis, or other aches and pains.', '', 50, 560, 1560, 5, 'uploaded_photos/painkiller.jpg', 'Available', 'suu', '0701998718'),
(201746, 'fight bacterial infections in people and animals. They work by killing the bacteria or by making it hard for the bacteria to grow and multiply', '', 499, 607, 1200, 5, 'uploaded_photos/antibiotic.jpg', 'Available', 'suu', '07012939829'),
(201747, 'ibuprofen                                            ', '', 68, 1400, 1800, 12, 'uploaded_photos/anaesthetic.jpg', 'Available', 'ibuprofen', '254909090909'),
(201748, 'fight certain infections and can save lives when used properly. They either stop bacteria from reproducing or destroy them.', '', 50, 1200, 2000, 14, 'uploaded_photos/antibiotic-medication-concept-photo.jpg', 'Available', 'Antibiotics', '2547897478734'),
(201749, 'Male BGR-34 Blood Glucose Regulator                                                                                        ', '', 19, 400, 500, 19, 'uploaded_photos/blood.jpg', 'Available', 'Ayurveda', ''),
(201750, ' a medication used to treat glaucoma, epilepsy, altitude sickness, periodic paralysis, idiopathic intracranial hypertension (raised brain pressure of unclear cause), urine alkalinization, and heart failure.', '', 20, 300, 600, 0, 'uploaded_photos/anticon.jpg', 'Available', 'Acetazolamide', '254759744446'),
(201751, 'is a medication used to treat glaucoma, epilepsy, altitude sickness, periodic paralysis, idiopathic intracranial hypertension (raised brain pressure of unclear cause), urine alkalinization, and heart failure.', '', 30, 300, 600, 15, 'uploaded_photos/anticonvulsant.jpeg', 'Available', 'Acetazolamide', '45284732455'),
(201752, ' medications used to prevent or treat anxiety symptoms or disorders. They\'re sometimes called anti-anxiety medications or minor tranquilizers. Anxiolytic medications are habit-forming and can lead to dependency or a substance use disorder.', '', 10, 600, 800, 16, 'uploaded_photos/alpo.jpg', 'Available', 'alprazolam', '08732643234'),
(201753, 'Clonidine lowers blood pressure by decreasing the levels of certain chemicals in your blood.', '', 3, 900, 1200, 13, 'uploaded_photos/Clonidine.jpg', 'Available', 'Clonidine', '073724984');

-- --------------------------------------------------------

--
-- Table structure for table `tblpromopro`
--

CREATE TABLE `tblpromopro` (
  `PROMOID` int(11) NOT NULL,
  `PROID` int(11) NOT NULL,
  `PRODISCOUNT` double NOT NULL,
  `PRODISPRICE` double NOT NULL,
  `PROBANNER` tinyint(4) NOT NULL,
  `PRONEW` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpromopro`
--

INSERT INTO `tblpromopro` (`PROMOID`, `PROID`, `PRODISCOUNT`, `PRODISPRICE`, `PROBANNER`, `PRONEW`) VALUES
(1, 201737, 0, 119, 0, 0),
(2, 201738, 0, 199, 0, 0),
(7, 201743, 0, 1200, 0, 0),
(8, 201744, 0, 1500, 0, 0),
(9, 201745, 0, 1560, 0, 0),
(10, 201746, 0, 1200, 0, 0),
(11, 201747, 0, 1800, 0, 0),
(12, 201748, 0, 2000, 0, 0),
(13, 201749, 0, 50000, 0, 0),
(14, 201750, 0, 600, 0, 0),
(15, 201751, 0, 600, 0, 0),
(16, 201752, 0, 800, 0, 0),
(17, 201753, 0, 1200, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblsetting`
--

CREATE TABLE `tblsetting` (
  `SETTINGID` int(11) NOT NULL,
  `PLACE` text NOT NULL,
  `BRGY` varchar(90) NOT NULL,
  `DELPRICE` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsetting`
--

INSERT INTO `tblsetting` (`SETTINGID`, `PLACE`, `BRGY`, `DELPRICE`) VALUES
(1, 'Nairobi', 'NAI. 1', 50),
(2, 'Mombasa ', 'MBSA 1', 70);

-- --------------------------------------------------------

--
-- Table structure for table `tblstockin`
--

CREATE TABLE `tblstockin` (
  `STOCKINID` int(11) NOT NULL,
  `STOCKDATE` datetime DEFAULT NULL,
  `PROID` int(11) DEFAULT NULL,
  `STOCKQTY` int(11) DEFAULT NULL,
  `STOCKPRICE` double DEFAULT NULL,
  `USERID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblsummary`
--

CREATE TABLE `tblsummary` (
  `SUMMARYID` int(11) NOT NULL,
  `ORDEREDDATE` datetime NOT NULL,
  `CUSTOMERID` int(11) NOT NULL,
  `ORDEREDNUM` int(11) NOT NULL,
  `DELFEE` double NOT NULL,
  `PAYMENT` double NOT NULL,
  `PAYMENTMETHOD` varchar(30) NOT NULL,
  `ORDEREDSTATS` varchar(30) NOT NULL,
  `ORDEREDREMARKS` varchar(125) NOT NULL,
  `CLAIMEDADTE` datetime NOT NULL,
  `HVIEW` tinyint(4) NOT NULL,
  `USERID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsummary`
--

INSERT INTO `tblsummary` (`SUMMARYID`, `ORDEREDDATE`, `CUSTOMERID`, `ORDEREDNUM`, `DELFEE`, `PAYMENT`, `PAYMENTMETHOD`, `ORDEREDSTATS`, `ORDEREDREMARKS`, `CLAIMEDADTE`, `HVIEW`, `USERID`) VALUES
(1, '2022-08-21 06:24:24', 9, 93, 0, 0, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-05-25 00:00:00', 0, 0),
(3, '2022-08-21 06:27:09', 9, 94, 70, 269, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2019-08-21 00:00:00', 1, 0),
(4, '2022-05-25 05:41:20', 10, 96, 70, 1500, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-05-25 00:00:00', 0, 0),
(5, '2022-06-09 04:04:20', 21, 97, 0, 1200, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-13 00:00:00', 0, 0),
(6, '2022-06-09 04:33:12', 23, 98, 0, 1500, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-16 00:00:00', 0, 0),
(7, '2022-06-10 10:34:54', 31, 99, 0, 51500, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-16 00:00:00', 0, 0),
(9, '2022-06-16 10:36:45', 32, 100, 0, 1200, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-16 00:00:00', 0, 0),
(10, '2022-06-16 02:50:41', 51, 101, 50, 1500, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-22 00:00:00', 0, 0),
(11, '2022-06-16 05:14:33', 51, 102, 50, 1200, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-22 00:00:00', 0, 0),
(12, '2022-06-22 01:53:09', 51, 103, 50, 1200, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-22 00:00:00', 0, 0),
(13, '2022-06-22 01:59:23', 51, 104, 50, 1500, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-22 00:00:00', 0, 0),
(14, '2022-06-22 07:44:00', 52, 105, 50, 1500, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-22 00:00:00', 0, 0),
(15, '2022-06-22 08:05:29', 52, 106, 50, 1500, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-22 00:00:00', 0, 0),
(16, '2022-06-22 08:14:00', 52, 107, 50, 1200, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-22 00:00:00', 0, 0),
(17, '2022-06-26 10:16:29', 52, 108, 50, 1800, 'Cash on Delivery', 'Cancelled', 'Your order has been cancelled due to lack of communication and incomplete information.', '0000-00-00 00:00:00', 0, 0),
(18, '2022-06-29 11:46:03', 53, 109, 70, 1200, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-29 00:00:00', 0, 0),
(19, '2022-06-29 11:46:54', 53, 110, 50, 3000, 'Cash on Delivery', 'Confirmed', 'Your order has been confirmed.', '2022-06-29 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbluseraccount`
--

CREATE TABLE `tbluseraccount` (
  `USERID` int(11) NOT NULL,
  `U_NAME` varchar(122) NOT NULL,
  `U_USERNAME` varchar(122) NOT NULL,
  `U_PASS` varchar(122) NOT NULL,
  `U_ROLE` varchar(30) NOT NULL,
  `USERIMAGE` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluseraccount`
--

INSERT INTO `tbluseraccount` (`USERID`, `U_NAME`, `U_USERNAME`, `U_PASS`, `U_ROLE`, `USERIMAGE`) VALUES
(124, 'suu', 'suheiba', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', 'photos/COC-war-base-design.jpg'),
(126, 'Suheiba Yasin', 'suu', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', 'photos/1570180.jpg'),
(127, 'Anime', 'anime', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', ''),
(128, 'kamaal', 'kamaal', 'd0b9d0f5f227eca3322715480952bf71f0898002', 'Administrator', ''),
(129, 'larry', 'larry', '968845783c158b6287022517450dc1205322081b', 'Administrator', ''),
(130, 'saif', 'saif', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Staff', ''),
(131, 'hani', 'hani', 'b7b8646782b3b69308a94ae3e347d39130a6f434', 'Staff', ''),
(132, 'farida', 'farida', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Encoder', ''),
(133, 'gurisha', 'gurisha', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Staff', ''),
(134, 'admin', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', 'photos/ken.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblwishlist`
--

CREATE TABLE `tblwishlist` (
  `id` int(11) NOT NULL,
  `CUSID` int(11) NOT NULL,
  `PROID` int(11) NOT NULL,
  `WISHDATE` date NOT NULL,
  `WISHSTATS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblwishlist`
--

INSERT INTO `tblwishlist` (`id`, `CUSID`, `PROID`, `WISHDATE`, `WISHSTATS`) VALUES
(2, 9, 201742, '2019-08-21', '0'),
(3, 23, 201744, '2022-06-09', '0'),
(4, 51, 201744, '2022-06-22', '0'),
(5, 52, 201744, '2022-06-22', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`CATEGID`);

--
-- Indexes for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  ADD PRIMARY KEY (`CUSTOMERID`);

--
-- Indexes for table `tblorder`
--
ALTER TABLE `tblorder`
  ADD PRIMARY KEY (`ORDERID`),
  ADD KEY `USERID` (`USERID`),
  ADD KEY `PROID` (`PROID`),
  ADD KEY `ORDEREDNUM` (`ORDEREDNUM`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`PROID`),
  ADD KEY `CATEGID` (`CATEGID`);

--
-- Indexes for table `tblpromopro`
--
ALTER TABLE `tblpromopro`
  ADD PRIMARY KEY (`PROMOID`),
  ADD UNIQUE KEY `PROID` (`PROID`);

--
-- Indexes for table `tblsetting`
--
ALTER TABLE `tblsetting`
  ADD PRIMARY KEY (`SETTINGID`);

--
-- Indexes for table `tblstockin`
--
ALTER TABLE `tblstockin`
  ADD PRIMARY KEY (`STOCKINID`),
  ADD KEY `PROID` (`PROID`,`USERID`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tblsummary`
--
ALTER TABLE `tblsummary`
  ADD PRIMARY KEY (`SUMMARYID`),
  ADD UNIQUE KEY `ORDEREDNUM` (`ORDEREDNUM`),
  ADD KEY `CUSTOMERID` (`CUSTOMERID`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tbluseraccount`
--
ALTER TABLE `tbluseraccount`
  ADD PRIMARY KEY (`USERID`);

--
-- Indexes for table `tblwishlist`
--
ALTER TABLE `tblwishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `CATEGID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  MODIFY `CUSTOMERID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `tblorder`
--
ALTER TABLE `tblorder`
  MODIFY `ORDERID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tblpromopro`
--
ALTER TABLE `tblpromopro`
  MODIFY `PROMOID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblsetting`
--
ALTER TABLE `tblsetting`
  MODIFY `SETTINGID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblstockin`
--
ALTER TABLE `tblstockin`
  MODIFY `STOCKINID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblsummary`
--
ALTER TABLE `tblsummary`
  MODIFY `SUMMARYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbluseraccount`
--
ALTER TABLE `tbluseraccount`
  MODIFY `USERID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `tblwishlist`
--
ALTER TABLE `tblwishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
