
<footer>
    <div class="text-center">
        <p>© 2022 - Online Public Transport Courier System</p>
    </div>
</footer>

    <script src="js/bootstrap.bundle.min.js"></script>

</body>
</html>