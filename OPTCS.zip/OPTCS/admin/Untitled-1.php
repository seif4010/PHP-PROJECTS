<!-- Nairobi - mombasa cargo -->
<a style="text-decoration: none;"
                                    href="manage-cargo.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">Manage
                                    Cargo</a> <a style="text-decoration: none;"
                                    href="book-driver.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">BookDriver</a>

<!-- Nairobi - Mombasa cargo -->
<a style="text-decoration: none;"
                                    href="manage-cargo.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">Manage
                                    Cargo</a> <a style="text-decoration: none;"
                                    href="book-driver.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">BookDriver</a>

<!-- Nairobi - Busia cargo -->
<a style="text-decoration: none;"
                                    href="manage-cargo.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">Manage
                                    Cargo</a> <a style="text-decoration: none;"
                                    href="book-driver.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">BookDriver</a>

<!-- Nairobi Kericho cargo -->
<a style="text-decoration: none;"
                                    href="manage-cargo.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">Manage
                                    Cargo</a> <a style="text-decoration: none;"
                                    href="book-driver.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">BookDriver</a>

<!-- Nairobi - Kisumu cargo -->
<a style="text-decoration: none;"
                                    href="manage-cargo.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">Manage
                                    Cargo</a> <a style="text-decoration: none;"
                                    href="book-driver.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">BookDriver</a>

<!-- Nairobi - Nanyuki cargo -->
<a style="text-decoration: none;"
                                    href="manage-cargo.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">Manage
                                    Cargo</a> <a style="text-decoration: none;"
                                    href="book-driver.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">BookDriver</a>

<!-- Nairobi - Kiambu cargo -->
<a style="text-decoration: none;"
                                    href="manage-cargo.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">Manage
                                    Cargo</a> <a style="text-decoration: none;"
                                    href="book-driver.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">BookDriver</a>

<!-- Nairobi - Kiambu cargo -->
<a style="text-decoration: none;"
                                    href="manage-cargo.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">Manage
                                    Cargo</a> <a style="text-decoration: none;"
                                    href="book-driver.php?cargo-id=<?= base64_encode($row['id']) ?>&user-id=<?= base64_encode($row['user_id']) ?>&driver-id=<?= base64_encode($row['driver_id']) ?>">BookDriver</a>

<!--  -->