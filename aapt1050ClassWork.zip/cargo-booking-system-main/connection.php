<?php 

    $connect = mysqli_connect('localhost', 'root', '', 'cargo-booking-system');

?>