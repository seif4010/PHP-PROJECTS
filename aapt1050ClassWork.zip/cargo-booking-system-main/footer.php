
<footer>
    <div class="text-center">
        <p>© 2022 - Fantastic Five</p>
    </div>
</footer>

    <script src="js/bootstrap.bundle.min.js"></script>

</body>
</html>